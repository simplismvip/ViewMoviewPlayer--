//
//  OPVideoController.h
//  ViewMoviewPlayer
//
//  Created by Mac on 16/6/6.
//  Copyright © 2016年 yijia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DIYButton.h"

// 枚举值，包含水平移动方向和垂直移动方向
typedef NS_ENUM (NSInteger, PanDirection) {
    PanDirectionHorizontalMoved,
    PanDirectionVerticalMoved
};

@interface OPVideoController : UIViewController
@property (nonatomic, strong, readonly) DIYButton *back; // 返回按钮
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) NSTimer *timer; // 定时器

// 初始化方法
- (void)setupVideoByPath:(NSString *)path page:(NSInteger)page;
@end
