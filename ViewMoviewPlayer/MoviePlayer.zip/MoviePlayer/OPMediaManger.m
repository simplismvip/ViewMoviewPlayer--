//
//  OPMediaManger.m
//  ViewMoviewPlayer
//
//  Created by Mac on 16/6/6.
//  Copyright © 2016年 yijia. All rights reserved.
//

#import "OPMediaManger.h"

@implementation OPMediaManger

// 过滤视频文件
+ (BOOL)videoByPath:(NSString *)path page:(NSInteger)page
{
    // 首先给索引赋值
    // self.index = page;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSMutableArray *muArr = [NSMutableArray array];
    NSArray *contents = [fileManager contentsOfDirectoryAtPath:path error:nil];
    
    // 1> 首先过滤出 M_ 开头的文件
    for (NSString *fileName in contents) {
        
        NSArray *array;
        if ([fileName pathExtension].length > 0) {
            
            array = [fileName componentsSeparatedByString:@"_"];
        }
        
        if (array.count >= 2) {
            
            if ([array[1] isEqualToString:[NSString stringWithFormat:@"%ld", page]]) {
                
                NSRange range = NSMakeRange(0, 2);
                NSString *m_ = [fileName substringWithRange:range];
                if ([m_ isEqualToString:@"M_"]) {
                    
                    [muArr addObject:fileName];
                }
            }
        }
    }
    
    for (NSString *name in muArr) {
        
        NSString *extension = [[name pathExtension] lowercaseString];
        
        // 本地 local
        if ([extension isEqualToString:@"mp4"]) {
            
            // 首先要对文件进行一次筛查, page页
            NSString *key = [name componentsSeparatedByString:@"_"][1];
            if ([key isEqualToString:[NSString stringWithFormat:@"%ld", page]]) {
                
                return YES;
            }
            
        }else {// 网络 URL
            
            // 首先要对文件进行一次筛查, page页
            NSString *key = [name componentsSeparatedByString:@"_"][1];
            if ([key isEqualToString:[NSString stringWithFormat:@"%ld", page]]) {
                
                // 去掉换行符和空格等不合法格式
                NSString *pathString = [path stringByAppendingPathComponent:name];
                NSString *pathStr = [NSString stringWithContentsOfFile:pathString encoding:NSUTF8StringEncoding error:nil];
                pathStr = [pathStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                NSString *newString = [pathStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                NSString *ext = [[newString pathExtension] lowercaseString];
                
                if ([ext isEqualToString:@"mp4"]) {
                    
                    return YES;
                }
            }
        }
    }

    return NO;
}

// 过滤视频文件
+ (BOOL)audioByPath:(NSString *)path page:(NSInteger)page
{
    // 首先给索引赋值
    // self.index = page;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSMutableArray *muArr = [NSMutableArray array];
    NSArray *contents = [fileManager contentsOfDirectoryAtPath:path error:nil];
    
    // 1> 首先过滤出 M_ 开头的文件
    for (NSString *fileName in contents) {
        
        NSArray *array;
        if ([fileName pathExtension].length > 0) {
            
            array = [fileName componentsSeparatedByString:@"_"];
        }
        
        if (array.count >= 2) {
            
            if ([array[1] isEqualToString:[NSString stringWithFormat:@"%ld", page]]) {
                
                NSRange range = NSMakeRange(0, 2);
                NSString *m_ = [fileName substringWithRange:range];
                if ([m_ isEqualToString:@"V_"]) {
                    
                    [muArr addObject:fileName];
                }
            }
        }
    }
    
    for (NSString *name in muArr) {
        
        NSString *extension = [[name pathExtension] lowercaseString];
        
        // 本地 local
        if ([extension isEqualToString:@"mp3"]) {
            
            // 首先要对文件进行一次筛查, page页
            NSString *key = [name componentsSeparatedByString:@"_"][1];
            if ([key isEqualToString:[NSString stringWithFormat:@"%ld", page]]) {
                
                return YES;
            }
            
        }else{// 网络 URL
            
            // 首先要对文件进行一次筛查, page页
            NSString *key = [name componentsSeparatedByString:@"_"][1];
            if ([key isEqualToString:[NSString stringWithFormat:@"%ld", page]]) {
                
                // 去掉换行符和空格等不合法格式
                NSString *pathString = [path stringByAppendingPathComponent:name];
                NSString *pathStr = [NSString stringWithContentsOfFile:pathString encoding:NSUTF8StringEncoding error:nil];
                pathStr = [pathStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
                NSString *newString = [pathStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                NSString *ext = [[newString pathExtension] lowercaseString];
                
                if ([ext isEqualToString:@"mp3"]) {
                    
                    return YES;
                }
            }
            
        }
    }
    
    return NO;
}


@end
