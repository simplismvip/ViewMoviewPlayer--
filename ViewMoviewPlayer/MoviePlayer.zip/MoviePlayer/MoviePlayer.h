//
//  MoviePlayer.h
//  MoviePlayer
//
//  Created by Mac on 16/6/3.
//  Copyright © 2016年 yijia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DIYButton.h"
#import <MediaPlayer/MediaPlayer.h>

// 枚举值，包含水平移动方向和垂直移动方向
typedef NS_ENUM(NSInteger, PanDirection){
    PanDirectionHorizontalMoved,
    PanDirectionVerticalMoved
};

@interface MoviePlayer : UIView
@property (nonatomic, strong) MPMoviePlayerController *moviePlayer; // 视频播放控件
@property (nonatomic, strong, readonly) DIYButton *back; // 返回按钮
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) NSTimer *timer; // 定时器

// 初始化方法
// - (instancetype)initWithFrame:(CGRect)frame URL:(NSURL *)url;
// - (void)setupUIByPath:(NSString *)path page:(NSInteger)page;
// - (void)stopAction;
- (void)setupVideoByPath:(NSString *)path page:(NSInteger)page;
@end
