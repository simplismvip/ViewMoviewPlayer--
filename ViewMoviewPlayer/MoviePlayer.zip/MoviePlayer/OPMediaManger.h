//
//  OPMediaManger.h
//  ViewMoviewPlayer
//
//  Created by Mac on 16/6/6.
//  Copyright © 2016年 yijia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OPMediaManger : NSObject
+ (BOOL)videoByPath:(NSString *)path page:(NSInteger)page;
+ (BOOL)audioByPath:(NSString *)path page:(NSInteger)page;
@end
